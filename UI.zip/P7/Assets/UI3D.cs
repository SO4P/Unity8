﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UI3D : MonoBehaviour {

    public Slider HPStrip;
    public int Hp = 100;
    // Use this for initialization
    void Start () {
        HPStrip.value = HPStrip.maxValue = Hp;
    }

    // Update is called once per frame
    void Update()
    {
        Hp -= 1;
        HPStrip.value = Hp;    //适当的时候对血条执行操作
    }
}
