﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class move : MonoBehaviour {

    public GameObject cube;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        float translationX = Input.GetAxis("Horizontal");
        float translationZ = Input.GetAxis("Vertical");
        Vector3 loc = cube.transform.position;
        loc.x += translationX;
        loc.z += translationZ;
        cube.transform.position = Vector3.MoveTowards(cube.transform.position, loc, 10f * Time.deltaTime);
    }
}
